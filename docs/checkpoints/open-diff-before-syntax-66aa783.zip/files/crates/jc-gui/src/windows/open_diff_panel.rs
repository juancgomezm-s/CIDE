//! Native intentions over the shared two-open-document read model. No Git,
//! filesystem lookup, source decode, worker polling or editor buffer lives here.
use super::{
    git_panel::GitFrame,
    project_panel::ProjectPresentation,
    project_results::{ProjectResultRow,ProjectResultsPresentation},
    Action,State,
};
use jc_app::{diff_model::DiffSide,open_diff::OpenDiffState,CommandId,Modifiers};

impl State {
    pub(super) fn request_open_diff(&mut self)->Action {
        self.close_selector();
        self.open_diff_visible=true;
        self.explorer_focused=false;
        self.bottom.focused=false;
        self.open_diff_view.first();
        match self.open_diff.request(&self.workbench,&mut self.jobs) {
            Ok(())=>self.status=self.open_diff.message().to_owned(),
            Err(error)=>self.error(error),
        }
        Action::None
    }
    /// This may invalidate a result or cancel old work, but never admits source
    /// snapshots or accepts completions. TASKS_MESSAGE owns tick/accept.
    pub(super) fn validate_open_diff(&mut self)->bool {
        let changed=self.open_diff.validate_context(&self.workbench,&mut self.jobs);
        if changed {self.open_diff_view.first();}
        changed
    }
    pub(super) fn cancel_open_diff(&mut self)->Action {
        self.open_diff.cancel(&mut self.jobs);
        self.open_diff_visible=false;
        self.open_diff_view.first();
        self.status="Open documents comparison cancelled; refresh is explicit".into();
        Action::None
    }
    pub(super) fn navigate_open_diff(&mut self,side:DiffSide)->Action {
        self.validate_open_diff();
        match self.open_diff.select_hunk(self.open_diff.selected(),side,&mut self.workbench) {
            Ok(())=>{
                self.open_diff_visible=false;
                self.explorer_focused=false;
                self.bottom.focused=false;
                self.status="Open document hunk selected; source bytes unchanged".into();
            }
            Err(error)=>self.error(error),
        }
        Action::None
    }
    pub(super) fn open_diff_key(&mut self,code:usize,modifiers:Modifiers)->Action {
        if !self.open_diff_visible {return Action::None;}
        self.validate_open_diff();
        match (code,modifiers) {
            (0x1b,Modifiers::NONE)=>return self.execute(CommandId::DiffCancelOpen),
            (0x74,Modifiers::NONE)=>return self.execute(CommandId::DiffRefreshOpen),
            (0x0d,Modifiers::NONE)=>return self.execute(CommandId::DiffOpenNavigateRight),
            (0x0d,Modifiers::SHIFT)=>return self.execute(CommandId::DiffOpenNavigateLeft),
            _=>{},
        }
        if modifiers!=Modifiers::NONE {return Action::None;}
        match code {
            0x26|0x28=>{
                self.open_diff.select_relative(if code==0x26{-1}else{1});
                self.open_diff_view.first();
            }
            0x21=>self.open_diff_view.scroll_relative(-10),
            0x22=>self.open_diff_view.scroll_relative(10),
            0x24=>self.open_diff_view.first(),
            0x23=>self.open_diff_view.last(),
            _=>{},
        }
        Action::None
    }
    pub(super) fn open_diff_presentation(&mut self)->Option<GitFrame> {
        self.validate_open_diff();
        if !self.open_diff_visible {return None;}
        let (columns,_)=super::project_paint::field_geometry(self.width,self.height,self.cell_width,self.cell_height,1);
        let rows=super::project_paint::result_capacity(self.width,self.height,self.cell_width,self.cell_height);
        let prepared=self.open_diff_view.prepare(&self.open_diff,rows,columns,columns>=90);
        // The shared view's title is the same static description. Its message
        // carries bounded identities/encodings/state; labels never become paths.
        Some(GitFrame {
            panel:ProjectPresentation {
                fields:Vec::new(),active:0,status:self.open_diff.message().to_owned(),
                results:Some(ProjectResultsPresentation {
                    title:"Open documents comparison",message:prepared.message,
                    total:prepared.total,selected:prepared.selected,
                    rows:prepared.rows.into_iter().map(|row|ProjectResultRow {
                        index:if row.selected{prepared.selected}else{usize::MAX},
                        label:row.label,selected:row.selected,is_match:true,
                    }).collect(),
                }),
            },
            labels:super::project_paint::PanelLabels {
                draft:"Open documents (read-only)",
                policy:"Primary vs Secondary | explicit encodings | dirty snapshots | no Git or writes",
                footer:"Up/Down hunk | PgUp/Dn body | Shift+Enter left; Enter right | F5 refresh | Esc",
            },
        })
    }
    pub(super) fn open_diff_running(&self)->bool {
        matches!(self.open_diff.state(),OpenDiffState::Queued|OpenDiffState::Running)
    }
}
